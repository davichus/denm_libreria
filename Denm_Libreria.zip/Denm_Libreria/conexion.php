<?php
    $server="localhost";
    $user="root";
    $contrasena="";
    $db="denm_libreria";
    $conexion=mysqli_connect($server,$user,$contrasena) or die("Error al conectar al conectar al servidor")
?>