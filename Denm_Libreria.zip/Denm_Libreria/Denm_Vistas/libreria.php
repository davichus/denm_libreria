<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Libreria</title>
		<?php require_once "Menu_Master.php"; ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Registro Librerias</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmSuc">
					    <label>Libreria</label>
						<input type="text" class="form-control input-sm" id="txt_nom" name="txt_nom" >
						<label>Ruc</label>
                        <input type="text" class="form-control input-sm" id="txt_ruc" name="txt_ruc"  onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Direccion</label>
						<input type="text" class="form-control input-sm" id="txt_dir" name="txt_dir">
						<label>Telefono</label>
						<input type="text" class="form-control input-sm" id="txt_telf" name="txt_telf"  onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Correo</label>
						<input type="email" class="form-control input-sm" id="txt_correo" name="txt_correo">
                      
						<label>Descripcion</label>
						<textarea  id="txt_desc" name="txt_desc" class="form-control input-sm"></textarea>
						
						<p></p>
						<span class="btn btn-primary" id="btnAgregarCentro">Agregar</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaCentroLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalCentroUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Sucursal</h4>
					</div>
					<div class="modal-body">
						<form id="frmSucU">
                        <input type="text" hidden="" id="id" name="id">
						<label>Libreria</label>
						<input type="text" class="form-control input-sm" id="nom" name="nom">
						<label>Ruc</label>
                        <input type="text" class="form-control input-sm" id="ruc" name="ruc" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Direccion</label>
						<input type="text" class="form-control input-sm" id="dir" name="dir">
						<label>Telefono</label>
						<input type="text" class="form-control input-sm" id="telf" name="telf" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Correo</label>
						<input type="email" class="form-control input-sm" id="correo" name="correo">
                      
						<label>Descripcion</label>
						<textarea  id="desc" name="desc" class="form-control input-sm"></textarea>
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarSucU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
    
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaCentroLoad').load("libreria/tablaLibreria.php");

			$('#btnAgregarCentro').click(function(){

				vacios=validarFormVacio('frmSuc');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmSuc').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/libreria/agregaLib.php",
					success:function(r){
						if(r==2){
							$('#tablaCentroLoad').load("libreria/tablaLibreria.php");
								alertify.alert("Esta Libreria ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmSuc')[0].reset();

					$('#tablaCentroLoad').load("libreria/tablaLibreria.php");
					alertify.success("Libreria agregada con exito!!");
				}else{
					alertify.error("No se pudo agregar Libreria");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarSucU').click(function(){

				datos=$('#frmSucU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/libreria/actualizaLib.php",
					success:function(r){
						if(r==1){
							$('#tablaCentroLoad').load("libreria/tablaLibreria.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDatosCentro(id,nom,ruc,dir,telf,correo,desc){
			$('#id').val(id);
            $('#nom').val(nom);
            $('#ruc').val(ruc);
            $('#dir').val(dir);
            $('#telf').val(telf);
            $('#correo').val(correo);
            $('#desc').val(desc);
          
		}

		function eliminarCentro(id){
			alertify.confirm('¿Desea eliminar esta Libreria?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + id,
					url:"../denm_procesos/libreria/eliminaLib.php",
					success:function(r){
						if(r==1){
							$('#tablaCentroLoad').load("libreria/tablaLibreria.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
						alertify.confirm("Por favor ingresa solo letras!!")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
						alertify.confirm("Por favor ingresa solo numeros!!")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>