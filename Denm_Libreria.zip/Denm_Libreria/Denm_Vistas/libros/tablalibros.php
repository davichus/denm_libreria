<?php 
	
	require_once "../../Denm_Clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();

	$sql="SELECT l.lib_id,
    l.lib_isbn,
    l.lib_titulo,
    l.lib_año,
	a.aut_nombres,
	a.aut_apellidos,
	l.lib_otro,
    r.libr_nombre,
    c.cat_nombre,
	e.edi_nombre,
	l.lib_stock,
    l.lib_precio_compra,
    l.lib_porcentaje_venta,
	l.lib_precio_venta
    
   
from tbl_libros l
inner join tbl_libreria r on l.libr_id=l.libr_id
inner join tbl_categoria c on l.cat_id=c.cat_id
inner join tbl_editorial e on l.edi_id=e.edi_id
inner join tbl_autor a on l.aut_id=a.aut_id where lib_estado='A'";
	$result=mysqli_query($conexion,$sql);

 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><center><label>Usuarios Registrados</label></center></caption>
	<tr>
        
		<td>Isbn</td>
		<td>Titulo</td>
		<td>Año</td>
        <td>Autores</td>
        <td>Libreria</td>
        <td>Categoria</td>
		<td>Editorial</td>
		<td>Stock</td>
        <td>Precio de Compra</td>
        <td>Porcentaje de Venta</td>
        <td>Precio de Venta</td>
        
		<td colspan="2">Acciones</td>
	
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?></td>
		<td><?php echo $ver[2]; ?></td>
		<td><?php echo $ver[3]; ?></td>
		<td><?php echo $ver[4]; ?> <?php echo $ver[5]; ?><br>
		
		<?php if($ver[6]=='Ninguno'){?>
		<?php }else{?>
			<?php echo $ver[6]; ?>
			<?php }?>
		</td>
        <td><?php echo $ver[7]; ?></td>
        <td><?php echo $ver[8]; ?></td>
		<td><?php echo $ver[9]; ?></td>
		<?php if($ver[10]=='0'){ ?>
		<td class="btn btn-danger btn-xs"><?php echo $ver[10]; ?></td>
		<?php }else {?>
	    <td class="btn btn-success btn-xs"><?php echo $ver[10]; ?></td>
		<?php }?>
		<td><?php echo $ver[11]; ?> </td>
		<td><?php echo $ver[12]; ?>%</td>
		<td><?php echo $ver[13]; ?></td>
		<td>
		<span  data-toggle="modal" data-target="#actualizaUsuarioModal" class="btn btn-warning btn-xs" onclick="agregaDatosUsuario('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminarUsuario('<?php echo $ver[0]; ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>