<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Personas</title>
        <?php require_once "Menu_Master.php"; ?>
        <?php require_once "../Denm_Clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_dni,per_apepat,per_apemat,per_nombre
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
        ?>
          <script>
//Función que realiza la suma
     function Suma() {
   var ingreso1 = document.frmPersona.txt_compra.value;
   var ingreso2 = document.frmPersona.txt_por.value;
   try{
      //Calculamos el número escrito:
       ingreso1 = (isNaN(parseFloat(ingreso1)))? 0 : parseFloat(ingreso1);
       ingreso2 = (isNaN(parseFloat(ingreso2)))? 0 : parseFloat(ingreso2);
       document.frmPersona.txt_venta.value = ingreso1*(ingreso2/100)+ingreso1;
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
   }
   
</script>

        <script>
//Función que realiza la suma
     function Suma1() {
   var ingreso1 = document.frmPersonaU.compra.value;
   var ingreso2 = document.frmPersonaU.por.value;
   try{
      //Calculamos el número escrito:
       ingreso1 = (isNaN(parseFloat(ingreso1)))? 0 : parseFloat(ingreso1);
       ingreso2 = (isNaN(parseFloat(ingreso2)))? 0 : parseFloat(ingreso2);
       document.frmPersonaU.venta.value = ingreso1*(ingreso2/100)+ingreso1;
   }
   //Si se produce un error no hacemos nada
   catch(e) {}
   }
   
</script>

	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Datos del Libro</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmPersona" name="frmPersona" method="POST">
                   
					    <label>ISBN</label>
						<input type="text" class="form-control input-sm" id="txt_isbn" name="txt_isbn" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Titulo</label>
						<input type="text" class="form-control input-sm" id="txt_titulo" name="txt_titulo" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Año</label>
						<input type="text" class="form-control input-sm" id="txt_año" name="txt_año" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Autor</label>
			<select class="form-control input-sm" id="sl_autor" name="sl_autor">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_autor where aut_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Otro Autor</label>
						<input type="text" class="form-control input-sm" id="txt_otro" name="txt_otro" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
           
                        <label>Stock</label>
						<input type="number" class="form-control input-sm" id="txt_stock" name="txt_stock"  style="width : 60px; heigth : 1px" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Precio Compra</label>
						<input type="text" class="form-control input-sm" id="txt_compra" name="txt_compra" onKeyUp="Suma()" style="width : 60px; heigth : 1px" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Porcentaje de Venta</label>
                        <table>
						<td><input type="text" class="form-control input-sm" id="txt_por" name="txt_por" onKeyUp="Suma()" style="width : 60px; heigth : 1px" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
                        <td><label><h1>%</h1> </label></td>
                        </table>
                        <label>Precio de Venta</label>
						<input readonly type="text" class="form-control input-sm" id="txt_venta" name="txt_venta" style="width : 60px; heigth : 1px">
                        <label>Libreria</label>
			<select class="form-control input-sm" id="sl_lib" name="sl_lib">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_libreria where libr_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Categoria</label>
			<select class="form-control input-sm" id="sl_cat" name="sl_cat">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_categoria where cat_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Editorial</label>
			<select class="form-control input-sm" id="sl_edi" name="sl_edi">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_editorial where edi_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
                        
                        <p></p>
                        
                       <span class="btn btn-primary" id="btnAgregarPersona">Agregar</span>
                        <br>
                        <br>
                        <br>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaPersonaLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="actualizaUsuarioModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Libro</h4>
					</div>
					<div class="modal-body">
						<form id="frmPersonaU" name="frmPersonaU">
                        <input type="text" hidden="" id="id" name="id">
                        <label>ISBN</label>
						<input type="text" class="form-control input-sm" id="isbn" name="isbn" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Titulo</label>
						<input type="text" class="form-control input-sm" id="titulo" name="titulo" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Año</label>
						<input type="text" class="form-control input-sm" id="año" name="año" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Autor</label>
			<select class="form-control input-sm" id="autor" name="autor">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_autor where aut_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Otro Autor</label>
						<input type="text" class="form-control input-sm" id="otro" name="otro" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
           
                        <label>Stock</label>
						<input type="number" class="form-control input-sm" id="stock" name="stock"  style="width : 60px; heigth : 1px">
                        <label>Precio Compra</label>
						<input type="text" class="form-control input-sm" id="compra" name="compra" onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Porcentaje de Venta</label>
                        <table>
						<td><input type="text" class="form-control input-sm" id="por" name="por" onKeyUp="Suma1()" style="width : 60px; heigth : 1px" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();"></td>
                        <td><label><h1>%</h1> </label></td>
                        </table>
                        <label>Precio de Venta</label>
						<input readonly type="text" class="form-control input-sm" id="venta" name="venta" style="width : 60px; heigth : 1px">
                        <label>Libreria</label>
			<select class="form-control input-sm" id="lib" name="lib">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_libreria where libr_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Categoria</label>
			<select class="form-control input-sm" id="cat" name="cat">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_categoria where cat_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Editorial</label>
			<select class="form-control input-sm" id="edi" name="edi">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT *
				from tbl_editorial where edi_estado='A'";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
                       
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPersonaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
    
    <script type="text/javascript">
		$(document).ready(function(){

            $('#tablaPersonaLoad').load("libros/tablalibros.php");

			$('#btnAgregarPersona').click(function(){

				vacios=validarFormVacio('frmPersona');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmPersona').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/libros/agregaLibro.php",
					success:function(r){
						if(r==2){
							$('#tablaPersonaLoad').load("libros/tablalibros.php");
								alertify.alert("Este libro ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmPersona')[0].reset();

					$('#tablaPersonaLoad').load("libros/tablalibros.php");
					alertify.success("Persona agregada con exito!!");
				}else{
					alertify.error("No se pudo agregar Persona");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPersonaU').click(function(){

				datos=$('#frmPersonaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/libros/actualizaLib.php",
					success:function(r){
						if(r==1){
							$('#tablaPersonaLoad').load("libros/tablalibros.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDatosUsuario(id){

			$.ajax({
				type:"POST",
				data:"id=" + id,
				url:"../denm_procesos/libros/ObtenDatosLib.php",
				success:function(r){
					dato=jQuery.parseJSON(r);

					$('#id').val(dato['lib_id']);
                    $('#isbn').val(dato['lib_isbn']);
                    $('#titulo').val(dato['lib_titulo']);
                    $('#año').val(dato['lib_año']);
                    $('#autor').val(dato['aut_id']);
                    $('#otro').val(dato['lib_otro']);
                    $('#stock').val(dato['lib_stock']);
                    $('#compra').val(dato['lib_precio_compra']);
                    $('#por').val(dato['lib_porcentaje_venta']);
                    $('#venta').val(dato['lib_precio_venta']);
                    $('#lib').val(dato['libr_id']);
                    $('#cat').val(dato['cat_id']);
                    $('#edi').val(dato['edi_id']);
					
					
				}
			});
		}

		function eliminarUsuario(idusuario){
			alertify.confirm('¿Desea eliminar este Libro?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idusuario,
					url:"../denm_procesos/libros/eliminaLibro.php",
					success:function(r){
						
						 if(r==1){
							$('#tablaPersonaLoad').load("libros/tablalibros.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar :(");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}


	</script>

	
<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
						alertify.confirm("Por favor ingresa solo letras!!")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
						alertify.confirm("Por favor ingresa solo numeros!!")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>