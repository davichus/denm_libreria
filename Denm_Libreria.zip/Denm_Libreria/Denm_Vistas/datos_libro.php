<?php 
session_start();
if(isset($_SESSION['usuario'])){
	?>
<?php
include_once "Menu_Master.php";
include_once "base_de_datos.php";
if(!isset($_POST["txt_dato"])) exit;
$nom=$_POST["txt_dato"];

$sentencia = $base_de_datos->query("SELECT l.lib_id,
l.lib_isbn,
l.lib_titulo,
l.lib_año,
a.aut_nombres,
a.aut_apellidos,
l.lib_otro,
r.libr_nombre,
c.cat_nombre,
e.edi_nombre,
l.lib_stock,
l.lib_precio_compra,
l.lib_porcentaje_venta,
l.lib_precio_venta
from tbl_libros l
inner join tbl_libreria r on l.libr_id=l.libr_id
inner join tbl_categoria c on l.cat_id=c.cat_id
inner join tbl_editorial e on l.edi_id=e.edi_id
inner join tbl_autor a on l.aut_id=a.aut_id 
where l.Lib_Titulo='$nom' or l.Lib_Isbn='$nom' or concat_ws(' ',a.aut_nombres,a.aut_apellidos)like '%$nom%'");
$ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);
?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		
		<div>
			
		</div>
		<br>
		<table class="table table-bordered">
			<thead>
				<tr>
                    <th>ISBN</th>
                    <th>Titulo</th>
                    <th>Año</th>
                    <th>Autor</th>
                    <th>Libreria</th>
                    <th>Categoria</th>
                    <th>Editorial</th>
                    <th>Stock</th>
                    <th>Precio de Compra</th>
                    <th>Porcentaje de Venta</th>
                    <th>Precio de Venta</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($ventas as $venta){ ?>
				<tr>
                    <td><?php echo $venta->lib_isbn ?></td>
                    <td><?php echo $venta->lib_titulo ?></td>
                    <td><?php echo $venta->lib_año ?></td>
                    <td><?php echo $venta->aut_nombres ?>
                   <br> <?php echo $venta->aut_apellidos ?> 
                   <br>
                   <?php  if($venta->lib_otro=='Ninguno'){ ?> 
                   <?php  }else{ ?> 
                    <?php echo $venta->lib_otro ?> 
                    <?php  } ?> 
            </td>
                    <td><?php echo $venta->libr_nombre ?></td>
                    <td><?php echo $venta->cat_nombre ?></td>
                    <td><?php echo $venta->edi_nombre ?></td>
                    <?php  if($venta->lib_stock=='0'){ ?>
                    <td class="btn btn-danger btn-xs"><?php echo $venta->lib_stock ?></td>
                    <?php }else{ ?>
                     <td class="btn btn-success btn-xs"><?php echo $venta->lib_stock ?></td>
                     <?php } ?>
                    <td><?php echo $venta->lib_precio_compra ?></td>
                    <td><?php echo $venta->lib_porcentaje_venta ?></td>
                    <td><?php echo $venta->lib_precio_venta ?></td>
                    
				</tr>
				<?php } ?>
			</tbody>
		</table>
    </div>
       <!-- Modal -->
		
    <?php 
}else{
	header("location:../index.php");
}
?>