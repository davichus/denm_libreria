<?php 
session_start();
if(isset($_SESSION['usuario'])){
	?>
<?php
include_once "Menu_Master.php";
include_once "base_de_datos.php";
if(!isset($_POST["nombre"])) exit;
$nom=$_POST["nombre"];

$sentencia = $base_de_datos->query("SELECT * FROM tbl_editorial where edi_nombre='$nom'");
$ventas = $sentencia->fetchAll(PDO::FETCH_OBJ);
?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		
		<div>
			
		</div>
		<br>
		<table class="table table-bordered">
			<thead>
				<tr>
                    <th>Editorial</th>
                    
					<th colspan="2">Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($ventas as $venta){ ?>
				<tr>
                    <td><?php echo $venta->Edi_Nombre ?></td>
                    
                    
					<td>
						
                   
                    
		<span  data-toggle="modal" data-target="#actualizaVenta" class="btn btn-warning " onclick="agregaDato('<?php echo $venta->Edi_Id ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>

				
				
					
				</tr>
				<?php } ?>
			</tbody>
		</table>
    </div>
       <!-- Modal -->
		<div class="modal fade" id="actualizaVenta" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Editorial</h4>
					</div>
					<div class="modal-body">
						<form id="frmPersonaU" name="frmPersonaU">
                        <input type="text" hidden="" id="id" name="id">
                        <label>Editorial</label>
							<input type="text" id="edi" name="edi" class="form-control input-sm">
                        
           
                    
                      
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPersonaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
        </div>
        

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPersonaU').click(function(){

				datos=$('#frmPersonaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/editorial/actualizaEdi.php",
					success:function(r){
						if(r==1){
                            window.location="editorial.php";
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>





        <script type="text/javascript">
			function agregaDato(id){

$.ajax({
            type:"POST",
            data:"id=" + id,
            url:"../denm_procesos/editorial/obtenDatosEdi.php",
        success:function(r){
        dato=jQuery.parseJSON(r);

        $('#id').val(dato['edi_id']);
        $('#edi').val(dato['edi_nombre']);
      
       
     
}
});
}


		function eliminarProv(idper){
			alertify.confirm('¿Desea eliminar este Insumo?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idper,
					url:"../denm_procesos/insumos/eliminaInsumo.php",
					success:function(r){
						if(r==1){
                            $('#tablaPersonaLoad').load("insumos/tablaInsumo.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>






    <?php 
}else{
	header("location:../index.php");
}
?>