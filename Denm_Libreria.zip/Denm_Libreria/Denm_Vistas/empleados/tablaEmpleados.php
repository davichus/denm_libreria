<?php 
	
	require_once "../../Denm_Clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();

	$sql="SELECT u.empl_id,
    p.per_dni,
    p.per_apepat,
    p.per_apemat,
    p.per_nombre,
    f.Libr_Ruc,
    f.libr_nombre,
    u.Empl_Estado,
    u.Empl_Fecha_Registro
   
from tbl_Empleado u
inner join tbl_persona p on u.per_id=p.per_id
inner join tbl_libreria f on u.libr_id=f.libr_Id
where u.empl_estado='A'";
	$result=mysqli_query($conexion,$sql);

 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><center><label>Usuarios Registrados</label></center></caption>
	<tr>
		<td>Persona</td>
		<td>Libreria</td>
        <td>Estado</td>
        <td>Fecha de Registro</td>
        
		<td colspan="2">Acciones</td>
	
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></td>
		<td><?php echo $ver[5]; ?><?php echo $ver[6]; ?></td>
        <td><?php echo $ver[7]; ?></td>
        <td><?php echo $ver[8]; ?></td>
      
		<td>
		<span  data-toggle="modal" data-target="#actualizaUsuarioModal" class="btn btn-warning btn-xs" onclick="agregaDatosUsuario('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminarUsuario('<?php echo $ver[0]; ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>