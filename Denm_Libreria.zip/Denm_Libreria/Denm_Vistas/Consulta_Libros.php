<?php 
session_start();
if(isset($_SESSION['usuario'])){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Libreria</title>
		<?php require_once "Menu_Master.php"; ?>
    </head>



	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Consultar Datos de Los libros</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="datosLib" action="datos_libro.php" method="POST">
						<label>Digite Isbn o Autor del Libro</label>
						<input type="text" class="form-control input-sm" name="txt_dato" id="txt_dato" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                       
						<p></p>
						<center><input type="submit" class="btn btn-primary" value="Buscar" name="buscar"</center>

					</form>
				</div>
				<div class="col-sm-7">
					
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
        
		</div>

	</body>
	</html>
    
					
<script type="text/javascript">
	$(document).ready(function(){
		$('#tablaRolLoad').load("roles/tablaRol.php");

		$('#btnAgregaRol').click(function(){

			if($('#txt_rol').val()==""){
				alertify.alert("Debes agregar el rol");
				return false;
			}

			cadena="rol=" + $('#txt_rol').val() ;

					$.ajax({
						type:"POST",
						url:"../denm_procesos/roles/agregarol.php",
						data:cadena,
						success:function(r){

							if(r==2){
								$('#tablaRolLoad').load("roles/tablaRol.php");
								alertify.alert("Este Rol ya existe, prueba con otro!!");
							}
							else if(r==1){
								$('#frmRol')[0].reset();
								$('#tablaRolLoad').load("roles/tablaRol.php");
								alertify.success("Agregado con exito");
							}else{
								alertify.error("Fallo al agregar");
							}
						}
					});
		});
	});
</script>
	
	
	
	

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaRol').click(function(){

				datos=$('#frmRolU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/roles/actualizaRol.php",
					success:function(r){
						if(r==1){
							$('#tablaRolLoad').load("roles/tablaRol.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDato(idrol,rol){
			$('#idrol').val(idrol);
			$('#rol').val(rol);
		}

		function eliminaRol(idrol){
			alertify.confirm('¿Desea eliminar este Rol?', function(){ 
				$.ajax({
					type:"POST",
					data:"idrol=" + idrol,
					url:"../denm_procesos/roles/eliminarRol.php",
					success:function(r){
						if(r==1){
							$('#tablaRolLoad').load("roles/tablaRol.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>