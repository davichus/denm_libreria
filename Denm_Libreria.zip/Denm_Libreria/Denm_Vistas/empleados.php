<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Libreria</title>
        <?php require_once "Menu_Master.php"; ?>
        <?php require_once "../Denm_Clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_dni,per_apepat,per_apemat,per_nombre
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Administrar Empleados</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmRegistro">
                        
                    <label>Persona</label>
						<select class="form-control input-sm" id="sl_persona" name="sl_persona">
							<option value="">--Seleccione--</option>
							<?php while($ver=mysqli_fetch_row($result)): ?>
								<option value="<?php echo $ver[0] ?>"><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></option>
							<?php endwhile; ?>
						</select>
                    
                        <label>Libreria</label>
			<select class="form-control input-sm" id="sl_lib" name="sl_lib">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT libr_id,libr_ruc,

				libr_nombre
                            from tbl_libreria";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
			</select>
                        
						<p></p>
						<center><span class="btn btn-primary" id="registro">Registrar Empleado</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaUsuariosLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="actualizaUsuarioModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualiza Usuario</h4>
					</div>
					<div class="modal-body">
						<form id="frmRegistroU">
							<input type="text" hidden="" id="id" name="id">
			
                            <label>Persona</label>
			<select class="form-control input-sm" id="persona" name="persona">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT per_id,per_dni,per_apepat,per_apemat,per_nombre
                      from tbl_persona";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?> <?php echo $producto[3] ?> <?php echo $producto[4] ?></option>
				<?php endwhile; ?>
			</select>
                    
                        <label>Libreria</label>
			<select class="form-control input-sm" id="lib" name="lib">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT libr_id,libr_ruc,

				libr_nombre
                            from tbl_libreria";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
			</select>
							

						</form>
					</div>
					<div class="modal-footer">
						<button id="btnActualizaUsuario" type="button" class="btn btn-warning" data-dismiss="modal">Actualiza Usuario</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>

	<script type="text/javascript">
		function agregaDatosUsuario(id){

			$.ajax({
				type:"POST",
				data:"id=" + id,
				url:"../denm_procesos/empleados/obtenDatosEmpl.php",
				success:function(r){
					dato=jQuery.parseJSON(r);

					$('#id').val(dato['empl_id']);
					$('#persona').val(dato['per_id']);
					$('#lib').val(dato['libr_id']);
				
					
				}
			});
		}

		function eliminarUsuario(idusuario){
			alertify.confirm('¿Desea eliminar este empleado?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + idusuario,
					url:"../denm_procesos/empleados/eliminaEmpl.php",
					success:function(r){
						
						 if(r==1){
							$('#tablaUsuariosLoad').load('empleados/tablaEmpleados.php');
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar :(");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}


	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaUsuario').click(function(){

				datos=$('#frmRegistroU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/empleados/actualizaEmpl.php",
					success:function(r){

						if(r==1){
							$('#tablaUsuariosLoad').load('empleados/tablaEmpleados.php');
							alertify.success("Actualizado con exito :D");
						}else{
							alertify.error("No se pudo actualizar");
						}
					}
				});
			});
		});
	</script>

	<script type="text/javascript">
		$(document).ready(function(){

			$('#tablaUsuariosLoad').load('empleados/tablaEmpleados.php');

			$('#registro').click(function(){

				vacios=validarFormVacio('frmRegistro');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmRegistro').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/empleados/agregaEmpl.php",
					success:function(r){
						//alert(r);
                        if(r==2){
							$('#tablaUsuariosLoad').load('empleados/tablaEmpleados.php');
								alertify.alert("Este Empleado ya a sido registrado!!");
							}
						
						else if(r==1){
							$('#frmRegistro')[0].reset();
							$('#tablaUsuariosLoad').load('empleados/tablaEmpleados.php');
							alertify.success("Agregado con exito");
						}else{
							alertify.error("Fallo al agregar :(");
						}
					}
				});
			});
		});
	</script>
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
	<?php 
}else{
	header("location:../index.php");
}
?>