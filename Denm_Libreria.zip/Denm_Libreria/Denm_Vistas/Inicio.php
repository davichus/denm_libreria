<?php 
	session_start();
	if(isset($_SESSION['usuario'])){
		
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Inicio</title>
	<?php require_once "Menu_Master.php"; ?>
	<?php require_once "../Denm_Clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	
</head>
<body>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
<div class="panel panel-container">
			<div class="row">
				
			
			     <div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-teal panel-widget border-right">
						<div class="row no-padding">
						<em class="fa fa-xl "><img src="imagenes/libros.png" class="img-responsive">
						</em>
						
							<?php
				$sql="SELECT count(*)As total
				FROM tbl_libros";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

						

							<div class="text-muted">Libros</div>
						     
							

							
							<?php endwhile; ?>
							<a href="libros.php"> Ver Info</a>
						</div>
					</div>
				</div>
				
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-blue panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa">
						<img src="imagenes/shakespeare.png" class="img-responsive">
						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_autor";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Autores</div>
							<a href="autor.php"> Ver Info</a>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-orange panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa">

						<img src="imagenes/libro.png" class="img-responsive">
						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_editorial";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Editoriales</div>
							<a href="editorial.php"> Ver Info</a>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-red panel-widget ">
						<div class="row no-padding"><em class="fa fa-xl fa">
						<img src="imagenes/libreria.png" class="img-responsive">

						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_libreria";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Librerias</div>
						
							<a href="libreria.php"> Ver Info</a>
						
						
						</div>
					</div>
				</div>

            

			</div><!--/.row-->

			


          
		</div>
</body>
</html>
<?php 
	}else{
		header("location:../index.php");
	}
 ?>