<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Libreria</title>
	<link href="../css/bootstrap.min.css" rel="stylesheet">
	<link href="../css/font-awesome.min.css" rel="stylesheet">
	<link href="../css/datepicker3.css" rel="stylesheet">
	<link href="../css/styles.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/alertify.css">
<link rel="stylesheet" type="text/css" href="../librerias/alertifyjs/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="../librerias/select2/css/select2.css">


<script type="text/javascript" src="../librerias/jquery.min.js"></script>

<script src="../librerias/jquery-3.2.1.min.js"></script>
<script src="../librerias/alertifyjs/alertify.js"></script>
<script src="../librerias/bootstrap/js/bootstrap.js"></script>
<script src="../librerias/select2/js/select2.js"></script>

    <script src="../js/funciones.js"></script>
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>Navarrete</span>Tech</a>
				
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
				<img src="http://placehold.it/50/30a5ff/fff" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name"><?php echo $_SESSION['usuario']; ?></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
		<?php
		if($_SESSION['rol']=="1"):
         ?>
            <li class="parent "><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em> Sistema <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li><a class="" href="usuario.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Usuarios
					</a></li>
					<li><a class="" href="roles.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Roles
					</a></li>
					
				</ul>
			</li>
			<?php 
       endif;
          ?>
            <li class="parent "><a data-toggle="collapse" href="#sub-item-2">
				<em class="fa fa-navicon">&nbsp;</em> Procesos <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					
				
				<li><a class="" href="editorial.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Editorial
					</a></li>
					<li><a class="" href="autor.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Autores
                    </a></li>
                    <li><a class="" href="libros.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Libros
                    </a></li>
                
                    
		

					
					
				</ul>
			</li>
			
            <li class="parent "><a data-toggle="collapse" href="#sub-item-3">
				<em class="fa fa-navicon">&nbsp;</em> Colsultas<span data-toggle="collapse" href="#sub-item-3" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-3">
					
					<li><a class="" href="Consulta_Libros.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Datos de Libros
					</a></li>
					<li><a class="" href="Consulta_Editorial.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Editoriales Registradas
					</a></li>
				
					
				</ul>
			</li>
			


        <?php
		if($_SESSION['rol']=="1"):
         ?>
            <li class="parent "><a data-toggle="collapse" href="#sub-item-4">
				<em class="fa fa-navicon">&nbsp;</em> Prametros <span data-toggle="collapse" href="#sub-item-4" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-4">
					<li><a class="" href="libreria.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Librerias
					</a></li>
					<li><a class="" href="persona.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Personas
					</a></li>
					<li><a class="" href="empleados.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Empleados 
					</a></li>
					<li><a class="" href="categoria.php">
						<span class="fa fa-arrow-right">&nbsp;</span> Categorias
                    </a></li>
                
					
				</ul>
			</li>
			<?php 
       endif;
          ?>
			<li><a href="../denm_procesos/salir.php"><em class="fa fa-power-off">&nbsp;</em> Cerrar Session</a></li>
		</ul>
	</div><!--/.sidebar-->
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="inicio.php">
					<em class="fa fa-home"></em>
				</a></li>
				
			</ol>
		</div><!--/.row-->
		
		
		
		
		<div class="row">
			
				
				
				
					
			
			
			
			<div class="col-sm-12">
				<p class="back-link">Developer For<a href="#"> David Navarrete</a></p>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
	
	<script src="../js/jquery-1.11.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chart.min.js"></script>
	<script src="../js/chart-data.js"></script>
	<script src="../js/easypiechart.js"></script>
	<script src="../js/easypiechart-data.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<script src="../js/custom.js"></script>
	<script>
		window.onload = function () {
	var chart1 = document.getElementById("line-chart").getContext("2d");
	window.myLine = new Chart(chart1).Line(lineChartData, {
	responsive: true,
	scaleLineColor: "rgba(0,0,0,.2)",
	scaleGridLineColor: "rgba(0,0,0,.05)",
	scaleFontColor: "#c5c7cc"
	});
};
	</script>
		
</body>
</html>