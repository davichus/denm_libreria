<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/categorias.php";

	

	$datos=array(
		$_POST['idrol'],
		$_POST['rol']
			);

	$obj= new categoria();

	echo $obj->actualizaCat($datos);

 ?>