<?php 

require_once "../../denm_clases/conexion.php";
require_once "../../denm_clases/categorias.php";

	$obj= new categoria;

	echo $obj->eliminaCat($_POST['idrol']);

 ?>