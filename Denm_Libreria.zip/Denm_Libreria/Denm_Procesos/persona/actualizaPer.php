<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/persona.php";

	

	$datos=array(
        $_POST['idper'],
        $_POST['tipo'],
        $_POST['ced'],
        $_POST['apepat'],
        $_POST['apemat'],
        $_POST['nom'],
        $_POST['fecha'],
        $_POST['genero'],
        $_POST['dir'],
        $_POST['telf']
			);

	$obj= new persona();

	echo $obj->actualizaPersona($datos);

 ?>