<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/personas.php";

	$obj= new personas;

	echo $obj->eliminaPersona($_POST['idper']);

 ?>