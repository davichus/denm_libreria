<?php 


	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/persona.php";
	require_once "../../denm_clases/conexion1.php";

    $conexion=conexion();

	$obj= new persona();
    
     
	$datos=array(
		    $_POST['sl_tipo'],
            $_POST['txt_cedula'],
			$_POST['txt_apepat'],
			$_POST['txt_apemat'],
			$_POST['txt_nom'],
			$_POST['txt_fecha'],
            $_POST['sl_genero'],
            $_POST['txt_dir'],
			$_POST['txt_telf']
			
				);
     if(buscaRepetido($_POST['txt_cedula'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->agregaPersona($datos);
	
}
	
	function buscaRepetido($ced,$conexion){
		$sql="SELECT * from tbl_persona 
			where per_dni='$ced'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
 ?>