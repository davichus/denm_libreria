<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/persona.php";

	$obj= new persona;

	echo $obj->eliminaPersona($_POST['idper']);

 ?>