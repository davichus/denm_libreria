<?php 

require_once "../../denm_clases/conexion.php";
require_once "../../denm_clases/conexion1.php";
require_once "../../denm_clases/autor.php";

	$obj= new autor;

	echo json_encode($obj->obtenDatosAut($_POST['id']));

 ?>