<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/conexion1.php";
	require_once "../../denm_clases/autor.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['nom'],
        $_POST['ape']
			);

	$obj= new autor();

	echo $obj->actualizaAut($datos);

 ?>