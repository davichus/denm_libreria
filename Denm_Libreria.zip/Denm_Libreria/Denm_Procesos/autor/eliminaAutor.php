<?php 

require_once "../../denm_clases/conexion.php";
require_once "../../denm_clases/conexion1.php";
require_once "../../denm_clases/autor.php";

	$obj= new autor;

	echo $obj->eliminaAut($_POST['idrol']);

 ?>