<?php 
	session_start();
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/conexion1.php";
	require_once "../../denm_clases/autor.php";
	$fecha=date("Y-m-d");
	$conexion=conexion();
	//$idusuario=$_SESSION['iduser'];
    $edi=$_POST['txt_nom'];
    $ide=$_POST['txt_ape'];

	$datos=array(
        $edi,
        $ide);

	$obj= new autor();
    if(buscaRepetido($edi,$ide,$conexion)==1){
		echo 2;
	}else{
	echo $obj->agregaAut($datos);
	}

	function buscaRepetido($role,$aut,$conexion){
		$sql="SELECT * from tbl_autor 
			where aut_nombres='$role' and aut_apellidos='$aut'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}

 ?>