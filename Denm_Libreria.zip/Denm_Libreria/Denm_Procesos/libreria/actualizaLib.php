<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/libreria.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['nom'],
        $_POST['ruc'],
        $_POST['dir'],
        $_POST['telf'],
        $_POST['correo'],
        $_POST['desc'],
			);

	$obj= new libreria();

	echo $obj->actualizaSuc($datos);

 ?>