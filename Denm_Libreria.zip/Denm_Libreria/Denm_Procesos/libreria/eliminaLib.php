<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/libreria.php";

	$obj= new libreria;

	echo $obj->eliminaSuc($_POST['id']);

 ?>