<?php 

session_start();
require_once "../../denn_clases/conexion1.php";
$conexion=conexion();

		$rol=$_POST['rol'];
	

		if(buscaRepetido($rol,$conexion)==1){
			echo 2;
		}else{
			$sql="INSERT into tbl_tipoperfil(Tper_desperfil,
            Tper_estado) values ('$rol','A')";
			echo $result=mysqli_query($conexion,$sql);
		}


		function buscaRepetido($role,$conexion){
			$sql="SELECT * from tbl_tipoperfil 
				where Tper_desperfil='$role'";
			$result=mysqli_query($conexion,$sql);

			if(mysqli_num_rows($result) > 0){
				return 1;
			}else{
				return 0;
			}
		}


 ?>