<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/roles.php";

	

	$datos=array(
		$_POST['idrol'],
		$_POST['rol']
			);

	$obj= new roles();

	echo $obj->actualizaRol($datos);

 ?>