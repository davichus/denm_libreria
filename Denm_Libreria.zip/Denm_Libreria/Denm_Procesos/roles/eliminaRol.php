<?php 

	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/roles.php";

	$obj= new roles;

	echo $obj->eliminaRol($_POST['idrol']);

 ?>