<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/libros.php";
	require_once "../../denm_clases/conexion1.php";

	

	$datos=array(
        $_POST['id'],
        $_POST['isbn'],
        $_POST['titulo'],
        $_POST['año'],
        $_POST['autor'],
        $_POST['otro'],
        $_POST['stock'],
        $_POST['compra'],
        $_POST['por'],
        $_POST['venta'],
        $_POST['lib'],
        $_POST['cat'],
        $_POST['edi']
			);

	$obj= new libros();

	echo $obj->actualizalib($datos);

 ?>