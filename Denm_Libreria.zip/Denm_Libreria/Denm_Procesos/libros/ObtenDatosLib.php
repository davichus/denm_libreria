<?php 

require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/libros.php";
	require_once "../../denm_clases/conexion1.php";

	$obj= new libros;

	echo json_encode($obj->obtenDatosLib($_POST['id']));

 ?>