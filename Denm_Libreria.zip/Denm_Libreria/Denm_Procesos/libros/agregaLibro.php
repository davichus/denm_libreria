<?php 


	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/libros.php";
	require_once "../../denm_clases/conexion1.php";

    $conexion=conexion();

	$obj= new libros();
    
     
	$datos=array(
		    $_POST['txt_isbn'],
            $_POST['txt_titulo'],
			$_POST['txt_año'],
			$_POST['sl_autor'],
			$_POST['txt_otro'],
			$_POST['txt_stock'],
			$_POST['txt_compra'],
            $_POST['txt_por'],
            $_POST['txt_venta'],
            $_POST['sl_lib'],
            $_POST['sl_cat'],
			$_POST['sl_edi']
			
				);
     if(buscaRepetido($_POST['txt_titulo'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->agregaLib($datos);
	
}
	
	function buscaRepetido($ced,$conexion){
		$sql="SELECT * from tbl_libros 
			where lib_titulo='$ced'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
 ?>