<?php 

require_once "../../denm_clases/conexion.php";
require_once "../../denm_clases/usuarios.php";

require_once "../../denm_clases/SED.php";
	$obj= new usuarios;
	
	$contrasena=SED::encryption($_POST['pass']);
	$datos=array(
			$_POST['usu'],
			$contrasena
				);  
	echo $obj->nuevacontra($datos);
	


 ?>
