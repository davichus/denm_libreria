<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/conexion1.php";
	require_once "../../denm_clases/editorial.php";

	

	$datos=array(
		$_POST['id'],
		$_POST['edi']
			);

	$obj= new editorial();

	echo $obj->actualizaEdi($datos);

 ?>