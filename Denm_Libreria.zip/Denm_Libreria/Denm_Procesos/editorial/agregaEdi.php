<?php 
	session_start();
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/conexion1.php";
	require_once "../../denm_clases/editorial.php";
	$fecha=date("Y-m-d");
	$conexion=conexion();
	//$idusuario=$_SESSION['iduser'];
    $edi=$_POST['txt_edi'];
    $ide=$_POST['txt_ide'];

	$datos=array(
        $edi,
        $ide);

	$obj= new editorial();
    if(buscaRepetido($edi,$conexion)==1){
		echo 2;
	}else{
	echo $obj->agregaEdi($datos);
	}

	function buscaRepetido($role,$conexion){
		$sql="SELECT * from tbl_editorial 
			where edi_nombre='$role'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}

 ?>