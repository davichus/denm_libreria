<?php 

require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/conexion1.php";
	require_once "../../denm_clases/editorial.php";

	$obj= new editorial;

	echo json_encode($obj->obtenDatosEdi($_POST['id']));

 ?>