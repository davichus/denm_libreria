<?php 
	require_once "../../denm_clases/conexion.php";
	require_once "../../denm_clases/empleados.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['persona'],
        //$_POST['sucursal'],
        $_POST['lib']
			);

	$obj= new empleados();

	echo $obj->actualizaEmp($datos);

 ?>