<?php 

	class persona{

		public function agregaPersona($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into Tbl_Persona(Per_Tipo_Dni,
				                          Per_Dni,
                                          Per_Apepat,
                                          Per_Apemat,
                                          Per_Nombre,
										  Per_Fecha_Nac,
                                          Per_Genero,
                                          Per_Direccion,
                                          Per_Fono_Celular,
										  Per_Estado)
						values ('$datos[0]',
                               '$datos[1]',
                               '$datos[2]',
                               '$datos[3]',
                               '$datos[4]',
                               '$datos[5]',
                               '$datos[6]',
                               '$datos[7]',
							   '$datos[8]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaPersona($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_persona set per_tipo_dni='$datos[1]',
			                             per_dni='$datos[2]',
                                         per_apepat='$datos[3]',
                                         per_apemat='$datos[4]',
                                         per_nombre='$datos[5]',
										 per_fecha_nac='$datos[6]',
                                         per_genero='$datos[7]',
                                         per_direccion='$datos[8]',
                                         per_fono_celular='$datos[9]'
								where per_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaPersona($per_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_persona set per_estado='I'
								where per_id='$per_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>