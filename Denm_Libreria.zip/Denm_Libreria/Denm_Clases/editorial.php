<?php 

	class editorial{

		public function agregaEdi($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_editorial(Edi_Nombre,
                                            Edi_identificador,
                                            Edi_estado)
						values ('$datos[0]',
                                '$datos[1]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
		public function actualizaEdi($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_editorial set edi_nombre='$datos[1]'
								where edi_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaEdi($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_editorial set edi_estado='I'
								where edi_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}


		public function obtenDatosEdi($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT edi_id,
			edi_nombre,
			   edi_identificador,
			   edi_estado 
	   from tbl_editorial
					where edi_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		   
			$datos=array(
				
						'edi_id' => $ver[0],
							'edi_nombre' => $ver[1],
							'edi_identificador' => $ver[2],
							'edi_estado' => $ver[3]
							
						);

			return $datos;
		}

		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>