<?php 

	class categoria{



		public function agregaCat($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_categoria(Cat_Nombre,
										Cat_estado)
						values ('$datos[0]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
		public function actualizaCat($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_categoria set Cat_Nombre='$datos[1]'
								where cat_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaCat($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_categoria set cat_estado='I'
								where cat_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>