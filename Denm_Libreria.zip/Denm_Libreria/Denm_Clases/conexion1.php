<?php 
	function conexion()
	{
		return $conexion=mysqli_connect("localhost","root","","denm_libreria");
	}

 ?>