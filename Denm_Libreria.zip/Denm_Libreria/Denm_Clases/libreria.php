<?php 

	class libreria{

		public function agregaSuc($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_libreria(libr_nombre,
                                          libr_ruc,
                                          libr_direccion,
                                          libr_telefono,
                                          libr_correo,
                                          libr_desc,
                                          libr_estado)
						values ('$datos[0]',
                               '$datos[1]',
                               '$datos[2]',
                               '$datos[3]',
                               '$datos[4]',
                               '$datos[5]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaSuc($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_libreria set libr_nombre='$datos[1]',
                                         libr_ruc='$datos[2]',
                                         libr_direccion='$datos[3]',
                                         libr_telefono='$datos[4]',
                                         libr_correo='$datos[5]',
                                         libr_desc='$datos[6]'
								where libr_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaSuc($per_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_libreria set libr_estado='I'
								where libr_id='$per_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>