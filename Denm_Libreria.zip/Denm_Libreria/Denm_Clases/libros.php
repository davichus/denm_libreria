<?php 

	class libros{

		public function agregaLib($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into Tbl_libros(lib_isbn,
				                          lib_titulo,
                                          lib_año,
                                          aut_id,
                                          lib_otro,
										  lib_stock,
										  lib_precio_compra,
                                          lib_porcentaje_venta,
                                          lib_precio_venta,
                                          libr_id,
                                          cat_id,
                                          edi_id,
										  lib_Estado)
						values ('$datos[0]',
                               '$datos[1]',
                               '$datos[2]',
                               '$datos[3]',
                               '$datos[4]',
                               '$datos[5]',
                               '$datos[6]',
                               '$datos[7]',
							   '$datos[8]',
                               '$datos[9]',
                               '$datos[10]',
							   '$datos[11]',
								'A')";

			return mysqli_query($conexion,$sql);
		}
		public function obtenDatosLib($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT lib_id,
			Lib_isbn,
			   Lib_Titulo,
			   Lib_año,
			   aut_id,
			   lib_otro,
			   lib_stock,
			   lib_precio_compra,
			   lib_porcentaje_venta,
			   lib_precio_venta,
			   libr_id,
			   cat_id,
			   edi_id 
	   from tbl_libros
					where lib_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		   
			$datos=array(
				
						'lib_id' => $ver[0],
							'lib_isbn' => $ver[1],
							'lib_titulo' => $ver[2],
							'lib_año' => $ver[3],
							'aut_id' => $ver[4],
							'lib_otro' => $ver[5],
							'lib_stock' => $ver[6],
							'lib_precio_compra' => $ver[7],
							'lib_porcentaje_venta' => $ver[8],
							'lib_precio_venta' => $ver[9],
							'libr_id' => $ver[10],
							'cat_id' => $ver[11],
							'edi_id' => $ver[12]
							
						);

			return $datos;
		}
		public function actualizalib($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_libros set lib_isbn='$datos[1]',
			                             lib_titulo='$datos[2]',
                                         lib_año='$datos[3]',
                                         aut_id='$datos[4]',
                                         lib_otro='$datos[5]',
										 lib_stock='$datos[6]',
                                         lib_precio_compra='$datos[7]',
                                         lib_porcentaje_venta='$datos[8]',
                                         lib_precio_venta='$datos[9]',
										 libr_id='$datos[10]',
										 cat_id='$datos[11]',
										 edi_id='$datos[12]'
								where lib_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaLib($per_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_libros set lib_estado='I'
								where lib_id='$per_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>