<?php 

	class autor{



		public function agregaAut($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_autor(aut_Nombres,
										aut_apellidos,
                                        aut_estado)
						values ('$datos[0]',
                                '$datos[1]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
		public function actualizaAut($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_autor set  aut_nombres='$datos[1]',
			                               
                                           aut_apellidos='$datos[2]'
                                          
								where aut_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaAut($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_autor set aut_estado='I'
								where aut_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}


		public function obtenDatosAut($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT aut_id,
			aut_nombres,
			   aut_apellidos,
			   aut_estado 
	   from tbl_autor
					where aut_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		   
			$datos=array(
				
						'aut_id' => $ver[0],
							'aut_nombres' => $ver[1],
							'aut_apellidos' => $ver[2],
							'aut_estado' => $ver[3]
							
						);

			return $datos;
		}
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>