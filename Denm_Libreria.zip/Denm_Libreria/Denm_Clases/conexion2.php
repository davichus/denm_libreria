<?php
	
	$mysqli = new mysqli('localhost', 'root', '', 'denm_libreria');
	
	if($mysqli->connect_error){
		
		die('Error en la conexion' . $mysqli->connect_error);
		
	}
?>