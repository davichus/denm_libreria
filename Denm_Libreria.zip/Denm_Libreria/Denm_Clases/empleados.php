<?php 

	class empleados{

		public function agregaEmp($datos){
			$c= new conectar();
			$conexion=$c->conexion();
            $fecha=date('Y-m-d');
			$sql="INSERT into tbl_empleado(per_id,
                                      Libr_id,
                                      empl_estado,
                                      empl_fecha_registro)
						values ('$datos[0]',
                                '$datos[1]',
								'A',
                                curdate())";

			return mysqli_query($conexion,$sql);
        }
        public function obtenDatoseEmp($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT empl_id,
            per_id,
			libr_id
	         from tbl_empleado 
					where empl_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		  
			$datos=array(
                            'empl_id' => $ver[0],
                            'per_id' => $ver[1],
                            'libr_id' => $ver[2]
						);

			return $datos;
		}


		public function actualizaEmp($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_empleado set  per_id='$datos[1]',
			                               
                                           libr_id='$datos[2]'
                                          
								where empl_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaEmp($esp_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_empleado set empl_estado='I'
								where empl_id='$esp_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>