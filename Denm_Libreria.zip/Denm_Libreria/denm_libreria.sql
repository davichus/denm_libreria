-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-09-2020 a las 04:07:35
-- Versión del servidor: 10.4.8-MariaDB
-- Versión de PHP: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `denm_libreria`
--

-- --------------------------------------------------------
create database denm_libreria;
use denm_libreria;
--
-- Estructura de tabla para la tabla `tbl_autor`
--

CREATE TABLE `tbl_autor` (
  `Aut_Id` int(11) NOT NULL,
  `Aut_Nombres` varchar(200) DEFAULT NULL,
  `Aut_Apellidos` varchar(200) DEFAULT NULL,
  `Aut_Estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_autor`
--

INSERT INTO `tbl_autor` (`Aut_Id`, `Aut_Nombres`, `Aut_Apellidos`, `Aut_Estado`) VALUES
(1, 'JOANNE K', 'ROLLING', 'A'),
(2, 'JULIO ', 'VERNE', 'A'),
(3, 'PATRICK', 'SÜSKIND', 'A'),
(4, 'PAULO', 'COHELO', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_categoria`
--

CREATE TABLE `tbl_categoria` (
  `Cat_Id` int(11) NOT NULL,
  `Cat_Nombre` varchar(200) DEFAULT NULL,
  `Cat_Estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_categoria`
--

INSERT INTO `tbl_categoria` (`Cat_Id`, `Cat_Nombre`, `Cat_Estado`) VALUES
(1, 'TERROR', 'A'),
(2, 'SUSPENSO', 'A'),
(3, 'MISTERIO', 'A'),
(4, 'ACCION', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_editorial`
--

CREATE TABLE `tbl_editorial` (
  `Edi_Id` int(11) NOT NULL,
  `Edi_Nombre` varchar(200) DEFAULT NULL,
  `Edi_Identificador` varchar(200) DEFAULT NULL,
  `Edi_Estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_editorial`
--

INSERT INTO `tbl_editorial` (`Edi_Id`, `Edi_Nombre`, `Edi_Identificador`, `Edi_Estado`) VALUES
(6, 'BLOOMSBURY PUBLISHING', '000001', 'A'),
(7, 'PIERRE-JULES HETZEL', '000002', 'A'),
(8, 'ALIANZA', '000003', 'A'),
(9, 'DIOGENES VERLAG', '000004', 'A'),
(10, 'SANTILLANA', '000005', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_empleado`
--

CREATE TABLE `tbl_empleado` (
  `Empl_Id` int(11) NOT NULL,
  `Per_Id` int(11) DEFAULT NULL,
  `Libr_Id` int(11) DEFAULT NULL,
  `Empl_Estado` char(1) DEFAULT NULL,
  `Empl_Fecha_Registro` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_empleado`
--

INSERT INTO `tbl_empleado` (`Empl_Id`, `Per_Id`, `Libr_Id`, `Empl_Estado`, `Empl_Fecha_Registro`) VALUES
(2, 1, 1, 'A', '2020-09-07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_libreria`
--

CREATE TABLE `tbl_libreria` (
  `Libr_Id` int(11) NOT NULL,
  `Libr_Nombre` varchar(200) DEFAULT NULL,
  `Libr_Ruc` varchar(13) DEFAULT NULL,
  `Libr_Direccion` varchar(200) DEFAULT NULL,
  `Libr_Telefono` varchar(13) DEFAULT NULL,
  `Libr_Correo` varchar(100) DEFAULT NULL,
  `Libr_Desc` varchar(200) DEFAULT NULL,
  `Libr_Estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_libreria`
--

INSERT INTO `tbl_libreria` (`Libr_Id`, `Libr_Nombre`, `Libr_Ruc`, `Libr_Direccion`, `Libr_Telefono`, `Libr_Correo`, `Libr_Desc`, `Libr_Estado`) VALUES
(1, 'Libreria Española', '1750982405001', 'El Ejido', '2569785', 'libespañola@info.com', 'Ventas de Libros', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_libros`
--

CREATE TABLE `tbl_libros` (
  `Lib_Id` int(11) NOT NULL,
  `Lib_Isbn` varchar(200) DEFAULT NULL,
  `Lib_Titulo` varchar(200) DEFAULT NULL,
  `Lib_Año` varchar(30) DEFAULT NULL,
  `Aut_Id` int(11) DEFAULT NULL,
  `lib_otro` varchar(200) NOT NULL,
  `lib_stock` int(11) NOT NULL,
  `Lib_Precio_Compra` decimal(7,2) DEFAULT NULL,
  `Lib_Porcentaje_Venta` decimal(7,2) DEFAULT NULL,
  `Lib_Precio_Venta` decimal(7,2) DEFAULT NULL,
  `Libr_Id` int(11) DEFAULT NULL,
  `Cat_Id` int(11) DEFAULT NULL,
  `Edi_Id` int(11) DEFAULT NULL,
  `Lib_Estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_libros`
--

INSERT INTO `tbl_libros` (`Lib_Id`, `Lib_Isbn`, `Lib_Titulo`, `Lib_Año`, `Aut_Id`, `lib_otro`, `lib_stock`, `Lib_Precio_Compra`, `Lib_Porcentaje_Venta`, `Lib_Precio_Venta`, `Libr_Id`, `Cat_Id`, `Edi_Id`, `Lib_Estado`) VALUES
(1, '9788478884452', 'HARRY POTTER Y LA PIEDRA FILOSOFAL', '1998', 1, 'Ninguno', 4, '40.00', '14.00', '45.60', 1, 3, 6, 'A'),
(3, '9788445908983', 'VIAJE AL CENTRO DE LA TIERRA', '1864', 2, 'Ninguno', 3, '60.00', '14.00', '68.40', 1, 2, 7, 'A'),
(4, '9788478884957', 'HARRY POTTER Y LA CAMARA SECRETA', '1998', 1, 'Ninguno', 5, '45.00', '12.00', '50.40', 1, 3, 6, 'A'),
(5, '9789584224514', 'EL PERFUME', '1985', 3, 'NINGUNO', 3, '60.00', '14.00', '68.40', 1, 2, 9, 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_persona`
--

CREATE TABLE `tbl_persona` (
  `Per_Id` int(11) NOT NULL,
  `Per_Tipo_Dni` char(1) DEFAULT NULL,
  `Per_Dni` varchar(20) DEFAULT NULL,
  `Per_Apepat` varchar(100) DEFAULT NULL,
  `Per_Apemat` varchar(100) DEFAULT NULL,
  `Per_Nombre` varchar(100) DEFAULT NULL,
  `Per_Fecha_Nac` varchar(50) DEFAULT NULL,
  `Per_Genero` char(1) DEFAULT NULL,
  `Per_Direccion` varchar(200) DEFAULT NULL,
  `Per_Fono_Celular` varchar(20) DEFAULT NULL,
  `Per_Estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_persona`
--

INSERT INTO `tbl_persona` (`Per_Id`, `Per_Tipo_Dni`, `Per_Dni`, `Per_Apepat`, `Per_Apemat`, `Per_Nombre`, `Per_Fecha_Nac`, `Per_Genero`, `Per_Direccion`, `Per_Fono_Celular`, `Per_Estado`) VALUES
(1, 'C', '1750982404', 'NAVARRETE', 'MORALES', 'DAVID EFRAIN', '1998-12-03', 'M', 'Carapungo', '2429795', 'A'),
(9, 'C', '1725347353', 'CAMPAÑA', 'MORALES', 'KARLA', '2003-04-04', 'F', 'Carapungo', '256897', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tipoperfil`
--

CREATE TABLE `tbl_tipoperfil` (
  `Tper_id` int(11) NOT NULL,
  `Tper_desperfil` varchar(50) DEFAULT NULL,
  `Tper_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_tipoperfil`
--

INSERT INTO `tbl_tipoperfil` (`Tper_id`, `Tper_desperfil`, `Tper_estado`) VALUES
(1, 'Administrador', 'A'),
(2, 'Vendedor', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuario`
--

CREATE TABLE `tbl_usuario` (
  `Usu_Id` int(11) NOT NULL,
  `Per_Id` int(11) DEFAULT NULL,
  `Usu_correo` varchar(200) DEFAULT NULL,
  `Usu_nomlogin` varchar(50) DEFAULT NULL,
  `Usu_pass` varchar(50) DEFAULT NULL,
  `Tper_id` int(11) NOT NULL,
  `Usu_fecha` date DEFAULT NULL,
  `Usu_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_usuario`
--

INSERT INTO `tbl_usuario` (`Usu_Id`, `Per_Id`, `Usu_correo`, `Usu_nomlogin`, `Usu_pass`, `Tper_id`, `Usu_fecha`, `Usu_estado`) VALUES
(2, 1, 'davidnava@outlook.com', 'DNavarrete', 'RDJCRWV4bGZOY2ZlQVRLK2tBQWdFZz09', 1, '2020-09-07', 'A'),
(4, 9, 'karla@gmail.com', 'KCampaña', 'RDJCRWV4bGZOY2ZlQVRLK2tBQWdFZz09', 2, '2020-09-10', 'A');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_autor`
--
ALTER TABLE `tbl_autor`
  ADD PRIMARY KEY (`Aut_Id`);

--
-- Indices de la tabla `tbl_categoria`
--
ALTER TABLE `tbl_categoria`
  ADD PRIMARY KEY (`Cat_Id`);

--
-- Indices de la tabla `tbl_editorial`
--
ALTER TABLE `tbl_editorial`
  ADD PRIMARY KEY (`Edi_Id`);

--
-- Indices de la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  ADD PRIMARY KEY (`Empl_Id`),
  ADD KEY `Libr_Id` (`Libr_Id`),
  ADD KEY `Per_Id` (`Per_Id`);

--
-- Indices de la tabla `tbl_libreria`
--
ALTER TABLE `tbl_libreria`
  ADD PRIMARY KEY (`Libr_Id`);

--
-- Indices de la tabla `tbl_libros`
--
ALTER TABLE `tbl_libros`
  ADD PRIMARY KEY (`Lib_Id`),
  ADD KEY `Libr_Id` (`Libr_Id`),
  ADD KEY `Cat_Id` (`Cat_Id`),
  ADD KEY `Aut_Id` (`Aut_Id`),
  ADD KEY `Edi_Id` (`Edi_Id`);

--
-- Indices de la tabla `tbl_persona`
--
ALTER TABLE `tbl_persona`
  ADD PRIMARY KEY (`Per_Id`);

--
-- Indices de la tabla `tbl_tipoperfil`
--
ALTER TABLE `tbl_tipoperfil`
  ADD PRIMARY KEY (`Tper_id`);

--
-- Indices de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD PRIMARY KEY (`Usu_Id`),
  ADD KEY `Per_Id` (`Per_Id`),
  ADD KEY `Tper_id` (`Tper_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_autor`
--
ALTER TABLE `tbl_autor`
  MODIFY `Aut_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tbl_categoria`
--
ALTER TABLE `tbl_categoria`
  MODIFY `Cat_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tbl_editorial`
--
ALTER TABLE `tbl_editorial`
  MODIFY `Edi_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  MODIFY `Empl_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tbl_libreria`
--
ALTER TABLE `tbl_libreria`
  MODIFY `Libr_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tbl_libros`
--
ALTER TABLE `tbl_libros`
  MODIFY `Lib_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tbl_persona`
--
ALTER TABLE `tbl_persona`
  MODIFY `Per_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `tbl_tipoperfil`
--
ALTER TABLE `tbl_tipoperfil`
  MODIFY `Tper_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  MODIFY `Usu_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tbl_empleado`
--
ALTER TABLE `tbl_empleado`
  ADD CONSTRAINT `tbl_empleado_ibfk_1` FOREIGN KEY (`Libr_Id`) REFERENCES `tbl_libreria` (`Libr_Id`),
  ADD CONSTRAINT `tbl_empleado_ibfk_2` FOREIGN KEY (`Per_Id`) REFERENCES `tbl_persona` (`Per_Id`);

--
-- Filtros para la tabla `tbl_libros`
--
ALTER TABLE `tbl_libros`
  ADD CONSTRAINT `tbl_libros_ibfk_1` FOREIGN KEY (`Libr_Id`) REFERENCES `tbl_libreria` (`Libr_Id`),
  ADD CONSTRAINT `tbl_libros_ibfk_2` FOREIGN KEY (`Cat_Id`) REFERENCES `tbl_categoria` (`Cat_Id`),
  ADD CONSTRAINT `tbl_libros_ibfk_3` FOREIGN KEY (`Aut_Id`) REFERENCES `tbl_autor` (`Aut_Id`),
  ADD CONSTRAINT `tbl_libros_ibfk_4` FOREIGN KEY (`Edi_Id`) REFERENCES `tbl_editorial` (`Edi_Id`);

--
-- Filtros para la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD CONSTRAINT `tbl_usuario_ibfk_1` FOREIGN KEY (`Per_Id`) REFERENCES `tbl_persona` (`Per_Id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_2` FOREIGN KEY (`Tper_id`) REFERENCES `tbl_tipoperfil` (`Tper_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
